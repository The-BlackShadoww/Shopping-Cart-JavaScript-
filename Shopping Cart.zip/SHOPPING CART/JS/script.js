//! <<<<<<<<<<<< HTML elements  >>>>>>>>>>>>>>

let addToCartBtn = document.querySelectorAll('#addToCart');
let shoppingCart = document.querySelector('#shopping_cart');



//! <<<<<<<<<<<< Classes >>>>>>>>>>>>>> 


class Products{

    constructor(ProductNmae, price) {
        this.ProductNmae = ProductNmae;
        this.price = price;
    }

}


class UI {

    constructor() {

    }

    //todo <<<<<<< Adding products to Cart >>>>>>>> 

    static showProductInCart(Product) {

        let tr = document.createElement('tr');
        let td1 = document.createElement('td');
        td1.appendChild(document.createTextNode(Product.ProductNmae));
        let td2 = document.createElement('td');
        td2.className = 'text-end';
        td2.appendChild(document.createTextNode(Product.price));
        let td3 = document.createElement('td');
        td3.className = 'text-end';
        let a = document.createElement('a');
        a.setAttribute('href', '#');
        a.className = 'btn btn-danger btn-sm';
        a.innerText = 'Remove';

        td3.appendChild(a);
        tr.appendChild(td1);
        tr.appendChild(td2);
        tr.appendChild(td3);
        shoppingCart.appendChild(tr);

    }
 


    //todo <<<<<<< Removing products from Cart >>>>>>>> 

    static removeProductFromUI (target) {

        if(target.hasAttribute('href')) {
            let tr = target.parentElement.parentElement;
            tr.remove();

            //todo <<<<<<< Removing products from Local storage >>>>>>>> 

            Storage.removeProductFromLS(tr);
        }

    }


}


class Storage {

    //todo <<<<<<< Adding products to Local Storage >>>>>>>> 

    static productStorage() {

        let productList;

        if(localStorage.getItem('Products') == null) {
            productList = [];
        }
        else{
            productList = JSON.parse(localStorage.getItem('Products'))
        }

        return productList;

    }

    static storingProducts(product) {

        let products = Storage.productStorage();

        products.push(product)

        localStorage.setItem('Products', JSON.stringify(products));

    }


    //todo <<<<<<< Bringing products back to the UI from local storage >>>>>>>> 

    static productBackToUI() {

        let products = Storage.productStorage();

        products.forEach( item => {

            UI.showProductInCart(item);

        })
        
    } 


    //todo <<<<<<< Removing products from local storage >>>>>>>> 

    static removeProductFromLS (tr) {

        let products = Storage.productStorage();

        tr.removeChild(tr.lastChild);

        let tr_product = tr.children[0].textContent.trim();
        let tr_price = tr.children[1].textContent.trim();


        products.forEach((item, index) => {

            let product = item.ProductNmae; 
            let price = item.price; 

            if(tr_product == product && tr_price == price) {

                products.splice(index, 1);

            }
        });

        localStorage.setItem('Products', JSON.stringify(products));

    }

}

//! <<<---------------- Classes Ends ---------------- >>>




//! <<<<<<<<<<<< EventListers >>>>>>>>>>>>>>

document.addEventListener('DOMContentLoaded', Storage.productBackToUI());
shoppingCart.addEventListener('click', removeProduct);

addToCartBtn.forEach((item) => {

    item.addEventListener('click', (e) => {

        let ProductNmae = e.target.parentNode.parentNode.children[0].textContent;
        let productPrice = e.target.parentNode.parentNode.children[1].textContent;

        let newProducts = new Products(ProductNmae, productPrice);

        //todo <<<<<<< Adding products to UI Cart >>>>>>>> 

        UI.showProductInCart(newProducts);

        //todo <<<<<<< Adding products to Local Storage >>>>>>>> 

        Storage.storingProducts(newProducts);

    })
})



//! <<<<<<<<<<<< Functions >>>>>>>>>>>>>>


//todo <<<<<<< Removing products from Cart >>>>>>>> 

function removeProduct (e) {

    let target = e.target;

    UI.removeProductFromUI(target);

    
}

